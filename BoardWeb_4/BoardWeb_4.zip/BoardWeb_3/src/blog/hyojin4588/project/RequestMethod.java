package blog.hyojin4588.project;

public class RequestMethod {
	public static final int GET = 1;
	public static final int POST = 2;
}
