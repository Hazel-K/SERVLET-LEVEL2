package blog.hyojin4588.pjt;

public class Const {
	
	public static final String LOGIN_USER = "login_user";
//	public static final int BOARD_CNT = 10;

}
